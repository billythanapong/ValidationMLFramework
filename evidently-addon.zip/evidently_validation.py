"""
Standalone Evidently AI validation for Clementine mass-loss models.

Usage:
    python evidently_validation.py --reference 2022_2024.xlsx --current 2025_2026.xlsx
    python evidently_validation.py --reference ... --current ... --weights weights_folder/
    python evidently_validation.py --reference ... --current ... --models ml_rt ml_40 --output reports/

--weights points at a folder of bottle-weight Excel files (e.g. bottle_weight.xlsx,
the output of extract_bottle_parameters.py). Every file in it is read, appended and
cleaned into one lab_order -> weight lookup. Without it, weights come from the training CSV.

Outputs written to validation_reports/ (or --output path):
    YYYY-MM-DD_drift.html/json        data drift: reference vs current
    YYYY-MM-DD_{model}.html/json      regression performance per model
    YYYY-MM-DD_business.html          business summary with safety margins
    YYYY-MM-DD_index.html             links index, opens automatically
"""
from __future__ import annotations

import argparse
import pickle
import sys
import webbrowser
from datetime import date
from pathlib import Path
from string import Template

import openpyxl
import numpy as np
import pandas as pd
from evidently.legacy.pipeline.column_mapping import ColumnMapping
from evidently.legacy.metric_preset import DataDriftPreset, RegressionPreset
from evidently.legacy.report import Report


# CONFIG

MAIN_PROGRAM = Path(r"C:\\Clementine\\src\\clementine-2-gui-updates")
sys.path.insert(0,str(MAIN_PROGRAM))
ASSETS_DIR    = MAIN_PROGRAM / "assets"
TEMPLATES_DIR = Path(__file__).parent / "templates"

# Required columns: 
EXCEL_COL_MAP: dict[str, str] = {
    "laboratory_order":                          "lab_order",
    "1_packaging_size_ml":                       "volume_ml",
    "1_packaging_material":                      "material",
    "bulk_category":                             "bulk_category_raw",
    "average_weight_loss_increase_at_rt_pct":    "actual_rt",
    "average_weight_loss_increase_at_40dec_pct": "actual_40",
}



STUDY_MATERIALS = {"LDPE","HDPE","PE","PET","PP"}
STUDY_TYPE_COL = "1_packaging_type"
STUDY_TYPE = "bottle"


# Optional columns (used if present, blank cells allowed, never required):
#   container_weight_g  -> real empty-bottle weight; same input production asks for.
#   wall_thickness_cm   -> real measured wall thickness (cm); falls back to estimate per row.
BULK_WORD_MAP = {
    "conditioner" : "CON",
    "treatment" : "CON",
    "developer" : "HC",
    "haircolor" : "HC",
    "lightener" : "HC",
    "shampoo" : "SHP",
    "shp = shampoo" : "SHP",
    "shower gel" :"SG",
    "showergel" : "SG",
    "liquid soap" : "SG",
    "foam bath" : "SG",
    "hair color" : "HC",
    "spray conditioner" : "CON",
    "treatment" : "CON",
    "colored treatment" : "CON",
    "styling gel" : "GE"}



BULK_CAT_MAP: dict[str, str] = {
    "CON": "con = haircare (conditioner, treatment, pumpstray)",
    "HC":  "hc = haircolor, incl. bleach, developer",
    "SG":  "sg = showergel, liquid soap, foam bath",
    "SH":  "shp = shampoo",
    "SHP": "shp = shampoo",
    "TRT": "trt",
    "GE":  "ge = styling gel or wax à styling non aerosol",
}

MATERIAL_COLS = [
    "1. packaging material_ldpe",
    "1. packaging material_hdpe",
    "1. packaging material_pe",
    "1. packaging material_pet",
    "1. packaging material_pp",
]

BULK_CAT_COLS = [
    "Bulk category_con = haircare (conditioner, treatment, pumpstray)",
    "Bulk category_hc = haircolor, incl. bleach, developer",
    "Bulk category_sg = showergel, liquid soap, foam bath",
    "Bulk category_shp = shampoo",
    "Bulk category_trt",
]

FAIL_THRESHOLDS: dict[str, float] = {
    "rt": 1.0,
    "40": 3.0,
}


ALL_MODELS = ["ml_rt", "ml_40", "physics_rt", "physics_40"]

MODEL_FILES = {
    "ml_rt":      "2025-03-24_mass_loss_model_RT.pkl",
    "ml_40":      "2025-03-24_mass_loss_model_40deg.pkl",
    "physics_rt": "transmission_model_RT.pkl",
    "physics_40": "transmission_model_40.pkl",
}

MODEL_DISPLAY = {
    "ml_rt":      "ML — Room Temp",
    "ml_40":      "ML — 40 °C",
    "physics_rt": "Physics formula — Room Temp",
    "physics_40": "Physics formula — 40 °C",
}


# set the actual and pred col for each of model
ACTUAL_COL: dict[str, str] = {
    "ml_rt":      "actual_rt",
    "ml_40":      "actual_40",
    "physics_rt": "actual_rt",
    "physics_40": "actual_40",
}

PRED_COL: dict[str, str] = {
    "ml_rt":      "pred_ml_rt",
    "ml_40":      "pred_ml_40",
    "physics_rt": "pred_physics_rt",
    "physics_40": "pred_physics_40",
}

# Features compared reference-vs-current in the drift report. Add a column name here
# to include it (it must exist after prepare_features / add_physics has run).

DRIFT_FEATURES = (
    ["1. packaging size [ml]", "Container weight [g]",
     "bottle surface area/thickness (cm)", "bottle weakness"]
    + MATERIAL_COLS + BULK_CAT_COLS
)


def load_excel(path: str) -> pd.DataFrame:
    p = Path(path)
    if not p.exists():
        sys.exit(f"ERROR: File not found — {p}")
    
    #  load data from designated path
    df = pd.read_excel(p)

    # try to solve the duplicate col name like lab_order
    seen, cols = {}, []
    for c in df.columns:
        n =str(c).strip().lower().replace(" ","_")
        seen[n] = seen.get(n,0) + 1
        cols.append(n if seen[n] == 1 else f"{n}_{seen[n]}")
    df.columns = cols

    # to check whether all required cols exist 
    missing = [k for k in EXCEL_COL_MAP if k not in df.columns]
    if missing:
        sys.exit(
            f"ERROR: Missing columns in {p.name}:\n  {missing}\n"
            "Check EXCEL_COL_MAP in this script matches your rename output."
        )
    return df.rename(columns=EXCEL_COL_MAP)




def get_container_weight(row: pd.Series, lab_lookup: dict) -> float | None:
    """Real container weight for one bottle, or None if none is available.

    Production never estimates weight (the user enters a measured value), so neither
    do we: use the Excel column if given, else the recorded training weight, else skip.
    """
    excel_w = row.get("container_weight_g")
    if pd.notna(excel_w) and float(excel_w) > 0:
        return float(excel_w)
    key = str(row["lab_order"]).strip()
    if key in lab_lookup:
        return float(lab_lookup[key])
    return None



def filter_study(df,label) :
    """filer the df for only bottle, only specific bulk category, and also mapping the correct name that CDP use""" 
    df = df.copy()
    n0 = len(df)
    df = df[df["material"].astype(str).str.strip().str.upper().isin(STUDY_MATERIALS)]

    df["bulk_category_raw"] = df["bulk_category_raw"].astype(str).str.strip().str.lower().map(BULK_WORD_MAP)
    df = df[df["bulk_category_raw"].notna()]
    if STUDY_TYPE_COL in df.columns:
        df = df[df[STUDY_TYPE_COL].astype(str).str.strip().str.lower() == STUDY_TYPE]
        print(f" {label} : kept {len(df)} / {n0} after study filter")
    return df




def _one_hot_material(mat_str: str) -> dict[str, float]:
    """ material in material col need to be exactly like ldpe / hdpe / pe / pet / pp"""
    mat = str(mat_str).strip().lower()
    return {
        "1. packaging material_ldpe": float(mat == "ldpe"),
        "1. packaging material_hdpe": float(mat == "hdpe"),
        "1. packaging material_pe":   float(mat == "pe"),
        "1. packaging material_pet":  float(mat == "pet"),
        "1. packaging material_pp":   float(mat == "pp"),
    }


def _one_hot_bulk(bulk_raw: str) -> dict[str, float]:
    """get the mapping bulk cat columns --> transform into """
    prefix = str(bulk_raw).split(":")[0].strip().upper()
    suffix = BULK_CAT_MAP.get(prefix, "")
    result = {c: 0.0 for c in BULK_CAT_COLS}
    target = f"Bulk category_{suffix}"
    if suffix and target in result:
        result[target] = 1.0
    return result



def add_physics(inputs: pd.DataFrame) -> pd.DataFrame:
    """Isolated copy of model_processing.add_physics() — no Streamlit imports needed."""
    lookup = pd.read_csv(ASSETS_DIR / "Physics_Lookup.csv")
    data   = inputs.copy()
    for prop in lookup.columns[1:]:
        # initiate the new col in data for that material
        data[prop] = 0.0 * data[lookup["1. packaging material"][0]]

        # loop through each pack material
        for i, mat in enumerate(lookup["1. packaging material"]):
            # add property for that material
            data[prop] += data[mat] * lookup[prop][i]
    vol  = data["1. packaging size [ml]"]
    wt   = data["Container weight [g]"]
    dens = data["package density (g/cm^3)"]
    E    = data["Youngs Modulus (GPa)"]
    data["surface_area_approx (cm^2)"]        = np.square(np.cbrt(vol)) * 5
    data["material volume (cm^3)"]             = wt / dens
    data["predicted wall thickness (cm)"]      = data["material volume (cm^3)"] / data["surface_area_approx (cm^2)"]

    if "real_wall_thickness_cm" in data.columns:
        # if we have real thickness it will show in 1 columns
        has_real = data["real_wall_thickness_cm"].notna()
        data["wall_thickness_cm"] = data["predicted wall thickness (cm)"].copy()
        data.loc[has_real, "wall_thickness_cm"] = data.loc[has_real, "real_wall_thickness_cm"]
        data["thickness_source"]       = np.where(has_real, "measured", "estimated")
        data["thickness_est_error_cm"] = data["predicted wall thickness (cm)"] - data["real_wall_thickness_cm"]
    else:
        data["wall_thickness_cm"] = data["predicted wall thickness (cm)"]

    t = data["wall_thickness_cm"]
    data["strength dimensions"]                = 1.0 / (vol ** (1/3) / (t**3 * E))
    data["bottle weakness"]                    = vol ** (1/3) / (t**3 * E)
    data["bottle surface area/thickness (cm)"] = data["surface_area_approx (cm^2)"] / t
    return data







def prepare_features(df: pd.DataFrame, lab_lookup: dict) -> pd.DataFrame:


    records, skipped = [], 0
    has_real_thickness = "wall_thickness_cm" in df.columns
    for _, row in df.iterrows():
        weight = get_container_weight(row, lab_lookup)
        if weight is None:                      # no real weight -> don't validate on a guess
            skipped += 1
            continue
        rec: dict = {
            "lab_order":              row["lab_order"],
            "actual_rt":              row["actual_rt"],
            "actual_40":              row["actual_40"],
            "1. packaging size [ml]": row["volume_ml"],
            "Container weight [g]":   weight,
        }
        # feed str of material to one hot
        rec.update(_one_hot_material(row["material"]))
        rec.update(_one_hot_bulk(row["bulk_category_raw"]))

        rec["actual_40"] = abs(pd.to_numeric(rec['actual_40'],errors="coerce"))
        rec["actual_rt"] = abs(pd.to_numeric(rec['actual_rt'],errors="coerce"))
        
        if has_real_thickness:
            rec["real_wall_thickness_cm"] = row.get("wall_thickness_cm", np.nan)  # retrieve the wall thickness from  dict if not exist return np.nan
        records.append(rec)

    if skipped:
        print(f"  skipped {skipped}/{len(df)} record(s) with no real container weight")
    if not records:
        sys.exit("ERROR: no records have a container weight — pass --weights, add a "
                 "container_weight_g column, or use bottles present in the training data.")
    return add_physics(pd.DataFrame(records))


def load_models() -> dict:
    models = {}
    for key, fname in MODEL_FILES.items():
        path = ASSETS_DIR / fname
        if not path.exists():
            sys.exit(f"ERROR: Model file not found — {path}")
        with open(path, "rb") as f:
            models[key] = pickle.load(f)
    return models


def run_predictions(df: pd.DataFrame, models: dict, selected: list[str]) -> pd.DataFrame:
    out = df.copy()
    for key in selected:
        m, cols, preds = models[key], models[key]["input_columns"], []
        for _, row in df.iterrows():
            try:
                if key.startswith("physics"):       # formula: predict() -> (percent, absolute)
                    perc, _ = m["model"].predict(row[cols].to_numpy())
                    preds.append(float(round(perc[0], 2)))
                else:                               # trained model: predict() -> array
                    x = row[cols].to_numpy().reshape(1, -1)
                    preds.append(float(round(m["model"].predict(x)[0], 2)))
            except Exception:
                preds.append(np.nan)
        out[PRED_COL[key]] = preds
        print(f"  {MODEL_DISPLAY[key]}: {sum(p == p for p in preds)}/{len(preds)} ok")
    return out


def build_reports(ref: pd.DataFrame, cur: pd.DataFrame, selected: list[str]) -> dict[str, Report | None]:
    """All Evidently reports: one data-drift report (reference vs current),
    plus one regression report per selected model (actual vs predicted)."""
    reports: dict[str, Report | None] = {}

    cols = [c for c in DRIFT_FEATURES if c in ref.columns and c in cur.columns]
    drift = Report(metrics=[DataDriftPreset(columns=cols)])
    drift.run(reference_data=ref[cols], current_data=cur[cols])
    reports["drift"] = drift

    for key in selected:
        target, pred = ACTUAL_COL[key], PRED_COL[key]
        sub = cur[["lab_order", target, pred]].dropna().copy()
        if len(sub) == 0:
            print(f"  WARNING: no valid rows for {key}")
            reports[key] = None
            continue
        rep = Report(metrics=[RegressionPreset()])
        rep.run(reference_data=None, current_data=sub,
                column_mapping=ColumnMapping(target=target, prediction=pred, id="lab_order"))
        reports[key] = rep
    return reports


def _temp_key(model_key: str) -> str:
    return "rt" if "rt" in model_key else "40"


def compute_business_metrics(df: pd.DataFrame, model_key: str) -> dict | None:
    # To add a business metric: compute it into the returned dict here, then add a
    # ${placeholder} for it in templates/business_report.html and pass it in build_business_html.
    target = ACTUAL_COL[model_key]
    pred   = PRED_COL[model_key]
    sub    = df[[target, pred]].dropna()
    if len(sub) == 0:
        return None

    actual    = sub[target]
    predicted = sub[pred]
    mae       = float(np.mean(np.abs(actual - predicted)))
    temp_k    = _temp_key(model_key)
    std_thr   = FAIL_THRESHOLDS[temp_k] # return 1 or 3 depends on which temp condition
    con_thr   = std_thr - mae
    n         = len(sub)
    a_fail    = actual >= std_thr
    n_fail    = int(a_fail.sum())
    n_pass    = n - n_fail

    def _counts(thr: float) -> tuple[int, int, int, int]:
        p_fail = predicted >= thr
        return (
            int(( a_fail &  p_fail).sum()), # TP: actual fail & predicted fail
            int((~a_fail & ~p_fail).sum()), # TN: actual pass & predicted pass
            int((~a_fail &  p_fail).sum()), # FP: actual pass & predicted fail  (over-reject)
            int(( a_fail & ~p_fail).sum()), # FN: actual fail & predicted pass  (missed failure)
        )

    TP_s, TN_s, FP_s, FN_s = _counts(std_thr)
    TP_c, TN_c, FP_c, FN_c = _counts(con_thr)

    def _safe_ratio(num: int, den: int) -> float | None:
        return num / den if den > 0 else None


    def _interpret_recall(value: float | None) -> str:
        if value is None:
            return "Not evaluable: no actual failures"
        if value == 1.0:
            return "All observed failures detected"
        if value == 0.0:
            return "No observed failures detected"
        return f"Detected {value * 100:.1f}% of observed failures"


    def _interpret_precision(value: float | None) -> str:
        if value is None:
            return "Not evaluable: no predicted failures"
        if value == 1.0:
            return "Every predicted failure was an actual failure"
        if value == 0.0:
            return "No predicted failures were actual failures"
        return f"{value * 100:.1f}% of failure warnings were correct"


    # Standard-threshold metrics
    std_recall = _safe_ratio(TP_s, TP_s + FN_s)
    std_precision = _safe_ratio(TP_s, TP_s + FP_s)
    std_fnr = _safe_ratio(FN_s, TP_s + FN_s)

    # Conservative-threshold metrics
    con_recall = _safe_ratio(TP_c, TP_c + FN_c)
    con_precision = _safe_ratio(TP_c, TP_c + FP_c)
    con_fnr = _safe_ratio(FN_c, TP_c + FN_c)

    return {
        "model_key":      model_key,
        "model_name":     MODEL_DISPLAY[model_key],
        "temperature":    "RT" if temp_k == "rt" else "40°C",
        "n":              n,
        "mae":            round(mae, 4),
        "std_thr":        std_thr,
        "con_thr":        round(con_thr, 4),
        "n_fail":         n_fail,
        "n_pass":         n_pass,
        "std_tp": TP_s, "std_tn": TN_s, "std_fp": FP_s, "std_fn": FN_s,
        "std_acc":        round((TP_s + TN_s) / n * 100, 1),
        "std_fn_rate":    round(FN_s / max(n_fail, 1) * 100, 1),
        "std_fp_rate":    round(FP_s / max(n_pass, 1) * 100, 1),
        "std_approved":   TN_s + FN_s,
        "con_tp": TP_c, "con_tn": TN_c, "con_fp": FP_c, "con_fn": FN_c,
        "con_acc":        round((TP_c + TN_c) / n * 100, 1),
        "con_fn_rate":    round(FN_c / max(n_fail, 1) * 100, 1),
        "con_fp_rate":    round(FP_c / max(n_pass, 1) * 100, 1),
        "con_approved":   TN_c + FN_c,
        "extra_rejected": (TN_s + FN_s) - (TN_c + FN_c), 
        "conf_pass":      int(((predicted + mae) <  std_thr).sum()),
        "conf_fail":      int(((predicted - mae) >= std_thr).sum()),
        "uncertain":      int((((predicted + mae) >= std_thr) & ((predicted - mae) < std_thr)).sum()),
                # Standard-threshold classification metrics
        "std_recall": (
            round(std_recall * 100, 1)
            if std_recall is not None else None
        ),
        "std_precision": (
            round(std_precision * 100, 1)
            if std_precision is not None else None
        ),
        "std_fnr": (
            round(std_fnr * 100, 1)
            if std_fnr is not None else None
        ),
        "std_recall_text": _interpret_recall(std_recall),
        "std_precision_text": _interpret_precision(std_precision),

        # Conservative-threshold classification metrics
        "con_recall": (
            round(con_recall * 100, 1)
            if con_recall is not None else None
        ),
        "con_precision": (
            round(con_precision * 100, 1)
            if con_precision is not None else None
        ),
        "con_fnr": (
            round(con_fnr * 100, 1)
            if con_fnr is not None else None
        ),
        "con_recall_text": _interpret_recall(con_recall),
        "con_precision_text": _interpret_precision(con_precision),
    }


def compute_model_agreement(df: pd.DataFrame, selected: list[str]) -> dict:
    pairs  = [("ml_rt", "physics_rt", "RT"), ("ml_40", "physics_40", "40°C")]
    result = {}
    for ml_key, ph_key, label in pairs:
        if ml_key not in selected or ph_key not in selected:
            continue
        thr   = FAIL_THRESHOLDS[_temp_key(ml_key)]
        sub   = df[[PRED_COL[ml_key], PRED_COL[ph_key]]].dropna()
        if len(sub) == 0:
            continue
        ml_f  = sub[PRED_COL[ml_key]] >= thr # series of TRUE/FALSE the pred of ml that more than standard threshold
        ph_f  = sub[PRED_COL[ph_key]] >= thr
        agree = int((ml_f == ph_f).sum()) # find only one that TRUE/TRUE or FALSE/FALSE
        result[label] = {   
            "n":           len(sub),
            "agree":       agree,
            "disagree":    len(sub) - agree,
            "agree_rate":  round(agree / len(sub) * 100, 1),
            "ml_stricter": int(( ml_f & ~ph_f).sum()),
            "ph_stricter": int((~ml_f &  ph_f).sum()),
        } # return result of key RT and 40 deg
    return result


def compute_thickness_comparison(df: pd.DataFrame) -> dict | None:
    if "thickness_est_error_cm" not in df.columns:
        return None
    measured = df[df["real_wall_thickness_cm"].notna()].copy()
    if len(measured) == 0:
        return None
    err = measured["thickness_est_error_cm"]
    return {
        "n_measured":     len(measured),
        "n_total":        len(df),
        "mae_cm":         float(err.abs().mean()),
        "bias_cm":        float(err.mean()),
        "overestimated":  int((err > 0).sum()),
        "underestimated": int((err < 0).sum()),
        "exact":          int((err == 0).sum()),
    }


def compute_outliers(df: pd.DataFrame, selected: list[str], n_per_model: int = 5) -> list[dict]:
    """Records with the largest actual-vs-predicted gap, per model — for traceback.
    Each row keeps its lab_order so an outlier in the report maps to a real bottle."""
    rows = []
    for key in selected:
        target, pred = ACTUAL_COL[key], PRED_COL[key]
        sub = df[["lab_order", target, pred]].dropna().copy()
        if sub.empty:
            continue
        sub["abs_err"] = (sub[pred] - sub[target]).abs()
        for _, r in sub.nlargest(n_per_model, "abs_err").iterrows():
            rows.append({
                "model":     MODEL_DISPLAY[key],
                "lab_order": r["lab_order"],
                "actual":    float(r[target]),
                "pred":      float(r[pred]),
                "error":     float(r[pred] - r[target]),
            })
    return rows


def _pct(num: int, den: int) -> str:
    return "—" if den == 0 else f"{num / den * 100:.1f}%"


def _thickness_section(t: dict | None) -> str:
    if not t:
        return ""
    bias_dir = "overestimates" if t["bias_cm"] > 0 else "underestimates"
    bias_cls = "amber" if abs(t["bias_cm"]) > 0.05 else "green"
    return f"""<section>
  <h2>Wall thickness <span class="section-note">predicted vs measured</span></h2>
  <div class="tbl-wrap"><table>
    <thead><tr>
      <th>Coverage</th><th>Mean abs. error</th><th>Bias</th>
      <th>Overestimated</th><th>Underestimated</th>
    </tr></thead>
    <tbody><tr>
      <td class="n">{t['n_measured']} / {t['n_total']} bottles</td>
      <td class="n"><span class="chip {'green' if t['mae_cm'] < 0.05 else 'amber'}">{t['mae_cm']*10:.2f} mm</span></td>
      <td class="n"><span class="chip {bias_cls}">{bias_dir} by {abs(t['bias_cm'])*10:.2f} mm</span></td>
      <td class="n">{t['overestimated']}</td>
      <td class="n">{t['underestimated']}</td>
    </tr></tbody>
  </table></div>
</section>"""


def _slug(lab: str) -> str:
    """Anchor-safe id for a lab order (used to link report -> record row)."""
    return "".join(ch if ch.isalnum() else "-" for ch in str(lab)).strip("-")


def _outlier_section(outliers: list[dict], records_file: str) -> str:
    if not outliers:
        return ""
    body = ""
    for o in outliers:
        cls  = "red" if abs(o["error"]) >= 1 else "amber"
        href = f'{records_file}#cur-{_slug(o["lab_order"])}'
        body += (f'<tr><td>{o["model"]}</td>'
                 f'<td class="n"><a href="{href}">{o["lab_order"]}</a></td>'
                 f'<td class="n">{o["actual"]:.2f}%</td>'
                 f'<td class="n">{o["pred"]:.2f}%</td>'
                 f'<td class="n"><span class="chip {cls}">{o["error"]:+.2f}%</span></td>'
                 f'<td><a href="{href}">see detail →</a></td></tr>')
    return f"""<section>
  <h2>Largest errors <span class="section-note">click a lab order to trace it in the records table</span></h2>
  <div class="tbl-wrap"><table>
    <thead><tr>
      <th>Model</th><th>Lab order</th><th>Actual</th><th>Predicted</th><th>Error</th><th>Detail</th>
    </tr></thead>
    <tbody>{body}</tbody>
  </table></div>
</section>"""


def build_business_html(
    metrics:   list[dict],
    agreement: dict,
    run_date:  str,
    n_current: int,
    thickness: dict | None = None,
    outliers:  list[dict] | None = None,
) -> str:
    total_fn  = sum(m["std_fn"] for m in metrics)
    total_fnc = sum(m["con_fn"] for m in metrics)
    conf_pass = metrics[0]["conf_pass"] if metrics else 0

    def chip(text: str, cls: str) -> str:
        return f'<span class="chip {cls}">{text}</span>'

    def fn_chip(fn: int, n_f: int) -> str:
        r = fn / max(n_f, 1) * 100
        return chip(f"{fn} ({r:.1f}%)", "red" if r > 20 else ("amber" if r > 5 else "green"))

    def fp_chip(fp: int, n_p: int) -> str:
        r = fp / max(n_p, 1) * 100
        return chip(f"{fp} ({r:.1f}%)", "amber" if r > 30 else "green")

    def pct_chip(v: float | None, good: float = 80) -> str:
        if v is None:
            return '<span class="muted">—</span>'
        cls = "green" if v >= good else ("amber" if v >= 50 else "red")
        return chip(f"{v:.1f}%", cls)

    rows_acc = rows_safe = rows_zone = ""
    for m in metrics:
        ac = "green" if m["std_acc"] >= 80 else "amber"
        rows_acc += f"""<tr>
<td>{m['model_name']}</td>
<td class="n">{m['mae']:.4f}%</td>
<td class="n">{m['n_fail']} / {m['n']}</td>
<td>{fn_chip(m['std_fn'], m['n_fail'])}</td>
<td>{fp_chip(m['std_fp'], m['n_pass'])}</td>
<td title="{m['std_recall_text']}">{pct_chip(m['std_recall'])}</td>
<td title="{m['std_precision_text']}">{pct_chip(m['std_precision'])}</td>
<td>{chip(f"{m['std_acc']}%", ac)}</td></tr>"""

        bc = "green" if m["con_acc"] >= 80 else "amber"
        rows_safe += f"""<tr>
<td>{m['model_name']}</td>
<td class="n">{m['con_thr']:.4f}%</td>
<td>{fn_chip(m['con_fn'], m['n_fail'])}</td>
<td>{fp_chip(m['con_fp'], m['n_pass'])}</td>
<td>{chip(f"{m['con_acc']}%", bc)}</td></tr>"""

        rows_zone += f"""<tr>
<td>{m['model_name']}</td>
<td>{chip(str(m['conf_pass']), 'green')}</td>
<td>{chip(str(m['conf_fail']), 'red')}</td>
<td>{chip(str(m['uncertain']), 'amber')}</td>
<td class="n">{_pct(m['conf_pass'], m['n'])}</td></tr>"""

    agree_rows = ""
    for temp, a in agreement.items():
        c = "green" if a["agree_rate"] >= 80 else "amber"
        agree_rows += f"""<tr>
<td>{temp}</td>
<td>{chip(f"{a['agree_rate']}%", c)} <span class="muted">({a['agree']} / {a['n']})</span></td>
<td class="n">{a['disagree']}</td>
<td class="n">{a['ml_stricter']}</td>
<td class="n">{a['ph_stricter']}</td></tr>"""

    fn_cls  = "stat-red"   if total_fn  > 0 else "stat-green"
    fnc_cls = "stat-amber" if total_fnc > 0 else "stat-green"

    if not agree_rows:
        agree_rows = ('<tr><td colspan="5" class="muted" style="padding:14px">'
                      'Select both ML and Physics models to see alignment.</td></tr>')

    template = Template((TEMPLATES_DIR / "business_report.html").read_text(encoding="utf-8"))
    return template.safe_substitute(
        n_current=n_current,
        total_fn=total_fn,
        total_fnc=total_fnc,
        conf_pass=conf_pass,
        fn_cls=fn_cls,
        fnc_cls=fnc_cls,
        rows_acc=rows_acc,
        rows_safe=rows_safe,
        rows_zone=rows_zone,
        agree_rows=agree_rows,
        thickness_section=_thickness_section(thickness),
        outlier_section=_outlier_section(outliers or [], f"{run_date}_records.html"),
    )


def save_record_errors(df: pd.DataFrame, selected: list[str], output_dir: Path, run_date: str) -> Path:
    """Every current bottle with its actual, predicted and error per model — the raw
    traceback behind the report. Open it and sort by any error_* column to find the
    outlier's lab_order and feed back to its source lab file."""
    base = [c for c in ("lab_order", "1. packaging size [ml]", "Container weight [g]") if c in df.columns]
    out  = df[base].copy()
    for key in selected:
        out[f"actual_{key}"] = df[ACTUAL_COL[key]]
        out[f"pred_{key}"]   = df[PRED_COL[key]]
        out[f"error_{key}"]  = df[PRED_COL[key]] - df[ACTUAL_COL[key]]
    path = output_dir / f"{run_date}_record_errors.csv"
    out.to_csv(path, index=False)
    return path






RECORD_COLS = {
    "1. packaging size [ml]":             "Size (ml)",
    "Container weight [g]":               "Weight (g)",
    "bottle weakness":                    "Weakness",
    "bottle surface area/thickness (cm)": "SA/thickness",
}


def _material_of(row: pd.Series) -> str:
    for col in MATERIAL_COLS:
        if row.get(col, 0) == 1:
            return col.rsplit("_", 1)[-1].upper()
    return "?"


def _records_table(df: pd.DataFrame, prefix: str, selected: list[str]) -> str:
    feat    = [c for c in RECORD_COLS if c in df.columns]
    headers = (["Lab order", "Material"]
               + [RECORD_COLS[c] for c in feat]
               + [f"{MODEL_DISPLAY[k]} err" for k in selected])
    head = "".join(f'<th title="{h} — click to sort">{h}</th>' for h in headers)

    body = ""
    for _, r in df.iterrows():
        slug = _slug(r["lab_order"])
        vals = [f'<a class="lab" href="#{prefix}-{slug}">{r["lab_order"]}</a>', _material_of(r)]
        for c in feat:
            vals.append(f"{r[c]:.4g}")
        for k in selected:
            pred, act = r.get(PRED_COL[k]), r.get(ACTUAL_COL[k])
            vals.append(f"{pred - act:+.2f}" if pd.notna(pred) and pd.notna(act) else "—")
        cells = ""
        for h, v in zip(headers, vals):
            cls = "" if h in ("Lab order", "Material") else ' class="n"'
            cells += f'<td{cls} title="{h}">{v}</td>'          # hover any cell -> its column name
        body += f'<tr id="{prefix}-{slug}">{cells}</tr>'
    return f"<table><thead><tr>{head}</tr></thead><tbody>{body}</tbody></table>"


def build_records_html(cur_df: pd.DataFrame, ref_df: pd.DataFrame,
                       selected: list[str], run_date: str) -> str:
    """Full current + reference record tables. Each row is anchored by lab_order so the
    report's outlier links (records.html#cur-<lab>) jump straight to that bottle's row."""
    template = Template((TEMPLATES_DIR / "records.html").read_text(encoding="utf-8"))
    return template.safe_substitute(
        run_date=run_date,
        n_current=len(cur_df),
        n_reference=len(ref_df),
        current_table=_records_table(cur_df, "cur", selected),
        reference_table=_records_table(ref_df, "ref", selected),
    )


def save_reports(
    reports:       dict[str, Report | None],
    output_dir:    Path,
    run_date:      str,
    business_html: str | None = None,
    records_html:  str | None = None,
) -> Path:
    output_dir.mkdir(parents=True, exist_ok=True)
    saved: dict[str, Path] = {}

    for name, report in reports.items():
        if report is None:
            continue
        stem = f"{run_date}_{name}"
        report.save_html(str(output_dir / f"{stem}.html"))
        report.save_json(str(output_dir / f"{stem}.json"))
        saved[name] = output_dir / f"{stem}.html"
        print(f"  saved {stem}.html")

    biz_path: Path | None = None
    if business_html:
        biz_path = output_dir / f"{run_date}_business.html"
        biz_path.write_text(business_html, encoding="utf-8")
        print(f"  saved {biz_path.name}")

    rec_path: Path | None = None
    if records_html:
        rec_path = output_dir / f"{run_date}_records.html"
        rec_path.write_text(records_html, encoding="utf-8")
        print(f"  saved {rec_path.name}")

    labels = {"drift": "Data drift"} | {k: MODEL_DISPLAY[k] for k in ALL_MODELS}
    rows   = "\n".join(
        f'<tr><td>{labels.get(n, n)}</td>'
        f'<td><a href="{p.name}">HTML</a></td>'
        f'<td><a href="{p.with_suffix(".json").name}">JSON</a></td></tr>'
        for n, p in saved.items()
    )
    if biz_path:
        rows += (
            f'\n<tr style="background:#f0fdf4"><td><b>Business summary</b></td>'
            f'<td><a href="{biz_path.name}">HTML</a></td><td>—</td></tr>'
        )
    if rec_path:
        rows += (
            f'\n<tr><td>Record tables (current + reference)</td>'
            f'<td><a href="{rec_path.name}">HTML</a></td><td>—</td></tr>'
        )

    index    = output_dir / f"{run_date}_index.html"
    template = Template((TEMPLATES_DIR / "index.html").read_text(encoding="utf-8"))
    index.write_text(template.safe_substitute(run_date=run_date, rows=rows), encoding="utf-8")
    return index


def save_prediction(cleaned_path,df, selected,output_dir,run_date,label) :
    tmp = df.drop_duplicates("lab_order").copy()
    tmp['lab_order'] = tmp['lab_order'].astype(str).str.strip()
    preds= tmp.set_index("lab_order")
    add_cols = list(preds.columns)
    wb = openpyxl.load_workbook(cleaned_path)
    ws = wb.active
    headers = [c.value for c in ws[1]]
    lab_col = headers.index("laboratory_order") + 1
    start = ws.max_column  + 1
    for i, c in enumerate(add_cols):
        ws.cell(row=1 , column=start+ i, value= str(c))
    for r in range(2, ws.max_row + 1) : 
        lab = str(ws.cell(row=r,column=lab_col).value).strip()
        if lab in preds.index:
            for i,c in enumerate(add_cols) : 
                v = preds.at[lab, c]
                if pd.isna(v) : 
                    val = None
                else :
                    try:
                        val = float(v)
                    except (ValueError,TypeError) : 
                        val = str(v)
                ws.cell(row=r,column=start+ i ,value = val)
    out = output_dir / f"{run_date}_{label}_with_predictions.xlsx"
    wb.save(out)
    return out



def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--reference", required=True)
    parser.add_argument("--current",   required=True)
    parser.add_argument("--models", nargs="+", default=ALL_MODELS, choices=ALL_MODELS)
    parser.add_argument("--output", default="validation_reports")
    args = parser.parse_args()

    run_date   = str(date.today())
    output_dir = Path(__file__).resolve().parent.parent / "output"

    output_dir.mkdir(parents=True, exist_ok=True)
    ref_raw = filter_study(load_excel(args.reference),"reference")
    cur_raw = filter_study(load_excel(args.current),"current")

    ref_df = prepare_features(ref_raw,{})
    cur_df = prepare_features(cur_raw,{})
    print(f"Reference: {len(ref_df)} bottles   Current: {len(cur_df)} bottles")

    models = load_models()
    ref_df = run_predictions(ref_df, models, args.models)
    cur_df = run_predictions(cur_df, models, args.models)

    reports = build_reports(ref_df, cur_df, args.models)

    biz_metrics = [m for key in args.models if (m := compute_business_metrics(cur_df, key))]
    agreement   = compute_model_agreement(cur_df, args.models)
    thickness   = compute_thickness_comparison(cur_df)
    outliers    = compute_outliers(cur_df, args.models)
    for m in biz_metrics:
        print(f"  {m['model_name']}: MAE={m['mae']:.4f}%  FN(std)={m['std_fn']}  FN(adj)={m['con_fn']}")
    if thickness:
        print(f"  thickness: {thickness['n_measured']}/{thickness['n_total']} measured  "
              f"MAE={thickness['mae_cm']*10:.2f}mm  bias={thickness['bias_cm']*10:+.2f}mm")

    biz_html = build_business_html(
        biz_metrics, agreement, run_date, len(cur_df), thickness, outliers
    ) if biz_metrics else None
    records_html = build_records_html(cur_df, ref_df, args.models, run_date)

    output_dir.mkdir(parents=True, exist_ok=True)
    save_prediction(args.reference,ref_df,args.models,output_dir,run_date,"reference")
    save_prediction(args.current,cur_df,args.models,output_dir,run_date,"current")

    err_csv = save_record_errors(cur_df, args.models, output_dir, run_date)
    index   = save_reports(reports, output_dir, run_date, biz_html, records_html)
    print(f"Done. Open {index}")
    print(f"Per-record errors (full traceback): {err_csv}")
    webbrowser.open(index.resolve().as_uri())


if __name__ == "__main__":
    main()
