r"""
Clean raw storage-test Excel into the shape evidently_validation.py expects.

Does three things:
  1. Read the raw Excel at --input.
  2. Rename its columns to the required names (edit RENAME below to match your file).
  3. Carry the lab-order hyperlink across: the raw lab-order cells are already clickable
     links to each bottle's file, so we read those links straight from the raw file and
     re-apply them on the output (pandas alone would drop them). Lab orders whose raw
     cell has no link are reported. --source-folder is an optional fallback only.

Usage:
    python .\src\evidently-addon\cleaning.py --input "src\raw\Technikum SP_2022 - AUG 2023.xlsx"
      --output "src\output\reference_clean.xlsx"

    python .\src\evidently-addon\cleaning.py --input "src\raw\Storage Test 2025-2026(AVG).xlsx" 
    --output "src\output\current_clean.xlsx" 
    --source-folder "C:\Users\likhit\OneDrive - Henkel\clementine\Project\Data\Data to Share CDP 2026\Storage Test 2025-2026"

The output feeds straight into evidently_validation.py:
    python evidently_validation.py --reference reference_clean.xlsx --current current_clean.xlsx
"""
from __future__ import annotations

import argparse
from pathlib import Path

import openpyxl
import pandas as pd

# Raw header (exactly as it appears in YOUR file)  ->  name evidently_validation.py expects.
# Edit the LEFT side so it matches your raw column titles. The RIGHT side must stay as-is
# (it mirrors EXCEL_COL_MAP in evidently_validation.py). Columns not listed are kept unchanged.
_SRC = Path(__file__).parent.parent
BOTTLE_WEIGHT_FILES = [str(_SRC / "raw" / "bottle_weight_since 2025.xlsx" ),
                       str(_SRC / "raw" / "bottle_weight_2022.xlsx"), 
                       str(_SRC / "raw" / "bottle_weight_2023.xlsx"),
                       str(_SRC / "raw" / "bottle_weight_2024.xlsx")]

RENAME = {
    "Laboratory Order / Testing report":                   "laboratory_order",
    "1. packaging size [ml]":                              "1_packaging_size_ml",
    "1. packaging material":                               "1_packaging_material",
    "Bulk category":    
                                                                          "bulk_category",
    "Average weight loss/increase at RT [%]":   "average_weight_loss_increase_at_rt_pct",
    "Average weight loss/increase at 40°C [%]": "average_weight_loss_increase_at_40dec_pct",
    # optional columns (kept if present):
    "Container weight [g]":                                "container_weight_g",
    "Wall thickness [cm]":                                 "wall_thickness_cm",

    # not necessary column just cleaned
    "Project Title"  :  "project_title",
    "Tested sample"  :  "tested_sample",
    "Brand"  :  "brand" ,
    "Projekt no."  :  "projekt_no" ,
    "PacLab Name"  :  "paclab_name" ,
    "Test period [weeks]"  :  "test_period_weeks" ,
    " Packaging manager"  :  "packaging_manager" ,
    "Start of ST"  :  "start_of_st" ,
    "End of ST"  :  "end_of_st" ,
    "Score of RT"  :  "score_of_rt" ,
    "Score of 40 Deg"  :  "score_of_40_deg" ,
    "Score Total"  :  "score_total" ,
    "RT result"  :  "rt_result" ,
    "40Deg Result"  :  "40deg_result" ,
    "Mass Loss Critical"  :  "mass_loss_critical" ,
    "RT weight per stroke [g]"  :  "rt_weight_per_stroke_g" ,
    "40°C weight per stroke [g]"  :  "40degc_weight_per_stroke_g" ,
    "Threaded moment [Nm / Ncm]"  :  "threaded_moment_nm___ncm" ,
    "RRL result [%]"  :  "rrl_result_pct" ,
    "RRL I result [%]"  :  "rrl_i_result_pct" ,
    "RRL II result [%]"  :  "rrl_ii_result_pct" ,
    "Packaging issues"  :  "packaging_issues" ,
    "Packaging issues at RT"  :  "packaging_issues_at_rt" ,
    "Packaging issues at 40°C"  :  "packaging_issues_at_40degc" ,
    "Leakage during ST"  :  "leakage_during_st" ,
    "Leakage during ST - RT"  :  "leakage_during_st___rt" ,
    "Leakage during ST - 40°C"  :  "leakage_during_st___40degc" ,
    "Vacuum test (before ST)"  :  "vacuum_test_before_st" ,
    "Vacuum test (after ST)"  :  "vacuum_test_after_st" ,
    "1. packaging description"  :  "1_packaging_description" ,
    "1. packaging SHAPE"  :  "1_packaging_shape" ,
    "1. packaging type"  :  "1_packaging_type" ,
    "1. recycled"  :  "1_recycled" ,
    "1. PCR content"  :  "1_pcr_content" ,
    "1. Mat.-No./ IDH"  :  "1_mat_no__idh" ,
    " 1. delivered from"  :  "1_delivered_from" ,
    "2. packaging description"  :  "2_packaging_description" ,
    "2. packaging type"  :  "2_packaging_type" ,
    "2. packaging material"  :  "2_packaging_material" ,
    "2. recycled"  :  "2_recycled" ,
    "2. PCR content"  :  "2_pcr_content" ,
    "2. Mat.-No./ IDH"  :  "2_mat_no__idh" ,
    " 2. delivered from "  :  "2_delivered_from" ,
    "3. packaging description"  :  "3_packaging_description" ,
    "3. packaging type"  :  "3_packaging_type" ,
    "3. recycled"  :  "3_recycled" ,
    "3. PCR content"  :  "3_pcr_content" ,
    "3. Mat.-No./ IDH"  :  "3_mat_no__idh" ,
    " 3. delivered from"  :  "3_delivered_from" ,
    "Formula no."  :  "formula_no" ,
    "Density"  :  "density" ,
    "  External filled samples"  :  "external_filled_samples" ,
    "Hot filling"  :  "hot_filling" ,
    "Bulk production site"  :  "bulk_production_site" ,
    "Bulk issues"  :  "bulk_issues" ,
}

LAB_ORDER_COL = "laboratory_order"   # the column (after rename) that carries the hyperlink

def add_weight(df,files) : 
    w = pd.concat([pd.read_excel(f) for f in files], ignore_index=False)
    w.to_excel(_SRC / "raw" / "all_bottle_weight_concat.xlsx")
    df['container_weight_g'] = df[LAB_ORDER_COL].map(dict(zip(w["lab_test_order"],w["bottle_weight_g"])))
    print(f"weight mapped {df['container_weight_g'].notna().sum()}/{len(df)}")
    return df


def clean(input_path: str, output_path: str, source_folder: str | None = None) -> None:
    df = pd.read_excel(input_path)
    df = df.rename(columns={k: v for k, v in RENAME.items() if k in df.columns})

    if LAB_ORDER_COL not in df.columns:
        raise SystemExit(
            f"ERROR: '{LAB_ORDER_COL}' not found after rename.\n"
            f"  Columns seen: {list(df.columns)}\n"
            f"  Fix the LEFT side of RENAME so it matches your raw header."
        )

    df[LAB_ORDER_COL] = df[LAB_ORDER_COL].astype(str).str.strip()
    row_count_start = len(df)

    # add cleaning vol column
    

    # add cleaning weight loss column
    for c in ["average_weight_loss_increase_at_rt_pct","average_weight_loss_increase_at_40dec_pct", "1_packaging_size_ml"]:
        if c in df.columns:
            s = df[c].astype(str).str.strip().str.replace(",",".",regex=False)
            df[c] = pd.to_numeric(s.str.extract(r"([-+]?\d*\.?\d+)")[0],errors="coerce")
            # df[c] = pd.to_numeric(df[c].astype(str).str.strip().str.replace(",",".",regex=False),errors="coerce")
    print(f"after convert to numeric, remaining row : {len(df)} from {row_count_start}")
    df = df.dropna(subset =["average_weight_loss_increase_at_rt_pct","average_weight_loss_increase_at_40dec_pct"],how="all" )
    print(f"after drop na, remaining row : {len(df)} from {row_count_start}")

    # add bottle weight mapping
    df = add_weight(df,BOTTLE_WEIGHT_FILES)

    links = _read_raw_links(input_path)   # {lab_order: hyperlink target} from the raw file

    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    df.to_excel(output_path, index=False)
    _apply_links(output_path, df[LAB_ORDER_COL].tolist(), links, source_folder)
    print(f"Saved {len(df)} rows -> {output_path}")


def _read_raw_links(raw_path: str) -> dict[str, str]:
    """Pull the existing hyperlink target off each lab-order cell in the raw file."""
    raw_header = next((k for k, v in RENAME.items() if v == LAB_ORDER_COL), None)
    wb = openpyxl.load_workbook(raw_path)
    ws = wb.active
    headers = [c.value for c in ws[1]]
    if raw_header not in headers:
        return {}
    col = headers.index(raw_header) + 1

    links: dict[str, str] = {}
    for row in range(2, ws.max_row + 1):
        cell = ws.cell(row=row, column=col)
        if cell.hyperlink and cell.value is not None:
            links[str(cell.value).strip()] = cell.hyperlink.target
    return links


def _apply_links(xlsx_path: str, labs: list[str], links: dict[str, str],
                 source_folder: str | None) -> None:
    """Write a hyperlink onto each output lab-order cell, from the raw links (preferred)
    or, failing that, a file named <lab_order>.xlsx in the optional fallback folder."""
    folder_files: dict[str, Path] = {}
    if source_folder:
        for folder in (source_folder or []) : 
            for f in Path(folder).rglob("*.xls*"):
                if not f.name.startswith("~") :
                    folder_files[f.stem.strip()] = f

    wb = openpyxl.load_workbook(xlsx_path)
    ws = wb.active
    col = [c.value for c in ws[1]].index(LAB_ORDER_COL) + 1

    missing = []
    for excel_row, lab in enumerate(labs, start=2):          # row 1 is the header
        key    = str(lab).strip()
        target = links.get(key)
        if not target and key in folder_files:
            target = str(folder_files[key].resolve())
        cell = ws.cell(row=excel_row, column=col)
        if target:
            cell.hyperlink = target
            cell.style = "Hyperlink"
        else:
            missing.append(lab)

    wb.save(xlsx_path)
    print(f"Linked {len(labs) - len(missing)}/{len(labs)} lab orders")
    if missing:
        shown = ", ".join(map(str, missing[:10]))
        print(f"  no link for {len(missing)}: {shown}{' ...' if len(missing) > 10 else ''}")


def main() -> None:
    ap = argparse.ArgumentParser(description="Clean raw storage-test Excel for evidently_validation.py")
    ap.add_argument("--input",  required=True, help="Raw Excel file to clean")
    ap.add_argument("--output", required=True, help="Cleaned Excel file to write")
    ap.add_argument("--source-folder",
                    nargs= "+",
                    help="Optional fallback: folder of files named <lab_order>.xlsx, "
                         "used only for lab orders whose raw cell has no hyperlink")
    args = ap.parse_args()
    clean(args.input, args.output, args.source_folder)


if __name__ == "__main__":
    main()
