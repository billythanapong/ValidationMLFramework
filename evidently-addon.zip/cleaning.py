"""
Clean raw storage-test Excel into the shape evidently_validation.py expects.

Does three things:
  1. Read the raw Excel at --input.
  2. Rename its columns to the required names (edit RENAME below to match your file).
  3. Carry the lab-order hyperlink across: the raw lab-order cells are already clickable
     links to each bottle's file, so we read those links straight from the raw file and
     re-apply them on the output (pandas alone would drop them). Lab orders whose raw
     cell has no link are reported. --source-folder is an optional fallback only.

Usage:
    python cleaning.py --input raw_current.xlsx --output current_clean.xlsx
    python cleaning.py --input raw_reference.xlsx --output reference_clean.xlsx

The output feeds straight into evidently_validation.py:
    python evidently_validation.py --reference reference_clean.xlsx --current current_clean.xlsx
"""
from __future__ import annotations

import argparse
from pathlib import Path

import openpyxl
import pandas as pd

# Raw header (exactly as it appears in YOUR file)  ->  name evidently_validation.py expects.
# Edit the LEFT side so it matches your raw column titles. The RIGHT side must stay as-is
# (it mirrors EXCEL_COL_MAP in evidently_validation.py). Columns not listed are kept unchanged.
RENAME = {
    "Laboratory Order / Testing report":                   "laboratory_order",
    "1. packaging size [ml]":                              "1_packaging_size_ml",
    "1. packaging material":                               "1_packaging_material",
    "Bulk category":                                       "bulk_category",
    "Average weight loss/increase at RT [%] / 12 weeks":   "average_weight_loss_increase_at_rt_pct",
    "Average weight loss/increase at 40°C [%] / 12 weeks": "average_weight_loss_increase_at_40dec_pct",
    # optional columns (kept if present):
    "Container weight [g]":                                "container_weight_g",
    "Wall thickness [cm]":                                 "wall_thickness_cm",
}

LAB_ORDER_COL = "laboratory_order"   # the column (after rename) that carries the hyperlink


def clean(input_path: str, output_path: str, source_folder: str | None = None) -> None:
    df = pd.read_excel(input_path)
    df = df.rename(columns={k: v for k, v in RENAME.items() if k in df.columns})

    if LAB_ORDER_COL not in df.columns:
        raise SystemExit(
            f"ERROR: '{LAB_ORDER_COL}' not found after rename.\n"
            f"  Columns seen: {list(df.columns)}\n"
            f"  Fix the LEFT side of RENAME so it matches your raw header."
        )

    df[LAB_ORDER_COL] = df[LAB_ORDER_COL].astype(str).str.strip()

    links = _read_raw_links(input_path)   # {lab_order: hyperlink target} from the raw file

    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    df.to_excel(output_path, index=False)
    _apply_links(output_path, df[LAB_ORDER_COL].tolist(), links, source_folder)
    print(f"Saved {len(df)} rows -> {output_path}")


def _read_raw_links(raw_path: str) -> dict[str, str]:
    """Pull the existing hyperlink target off each lab-order cell in the raw file."""
    raw_header = next((k for k, v in RENAME.items() if v == LAB_ORDER_COL), None)
    wb = openpyxl.load_workbook(raw_path)
    ws = wb.active
    headers = [c.value for c in ws[1]]
    if raw_header not in headers:
        return {}
    col = headers.index(raw_header) + 1

    links: dict[str, str] = {}
    for row in range(2, ws.max_row + 1):
        cell = ws.cell(row=row, column=col)
        if cell.hyperlink and cell.value is not None:
            links[str(cell.value).strip()] = cell.hyperlink.target
    return links


def _apply_links(xlsx_path: str, labs: list[str], links: dict[str, str],
                 source_folder: str | None) -> None:
    """Write a hyperlink onto each output lab-order cell, from the raw links (preferred)
    or, failing that, a file named <lab_order>.xlsx in the optional fallback folder."""
    folder_files: dict[str, Path] = {}
    if source_folder:
        folder_files = {
            f.stem.strip(): f
            for f in Path(source_folder).rglob("*.xls*")
            if not f.name.startswith("~")
        }

    wb = openpyxl.load_workbook(xlsx_path)
    ws = wb.active
    col = [c.value for c in ws[1]].index(LAB_ORDER_COL) + 1

    missing = []
    for excel_row, lab in enumerate(labs, start=2):          # row 1 is the header
        key    = str(lab).strip()
        target = links.get(key)
        if not target and key in folder_files:
            target = str(folder_files[key].resolve())
        cell = ws.cell(row=excel_row, column=col)
        if target:
            cell.hyperlink = target
            cell.style = "Hyperlink"
        else:
            missing.append(lab)

    wb.save(xlsx_path)
    print(f"Linked {len(labs) - len(missing)}/{len(labs)} lab orders")
    if missing:
        shown = ", ".join(map(str, missing[:10]))
        print(f"  no link for {len(missing)}: {shown}{' ...' if len(missing) > 10 else ''}")


def main() -> None:
    ap = argparse.ArgumentParser(description="Clean raw storage-test Excel for evidently_validation.py")
    ap.add_argument("--input",  required=True, help="Raw Excel file to clean")
    ap.add_argument("--output", required=True, help="Cleaned Excel file to write")
    ap.add_argument("--source-folder",
                    help="Optional fallback: folder of files named <lab_order>.xlsx, "
                         "used only for lab orders whose raw cell has no hyperlink")
    args = ap.parse_args()
    clean(args.input, args.output, args.source_folder)


if __name__ == "__main__":
    main()
